def success(string: str) -> None:
    print('SUCCESS: ' + string)


def warning(string: str) -> None:
    print('WARNING: ' + string)


def info(string: str) -> None:
    print('INFO: ' + string)


def error(string: str) -> None:
    print('ERROR: ' + string)
